-- Resume Rating weights — the 14-16 adjustable weights used to combine
-- normalized (1-10) metrics into a single conglomerate resume score.
-- One row per season. Weights stored as JSONB (not one column per
-- metric) deliberately, since metrics will change (SRS/VSRS/PGWE are
-- still being built) — this avoids a schema migration every time.

create table if not exists resume_rating_weights (
  id bigint generated always as identity primary key,
  season int not null unique,
  weights jsonb not null,
  updated_at timestamptz not null default now()
);

alter table resume_rating_weights enable row level security;

-- Public can read (for the eventual public Resume Ratings page); only the
-- admin-authenticated endpoint (service role key, bypasses RLS) can write.
drop policy if exists "public read" on resume_rating_weights;
create policy "public read" on resume_rating_weights for select using (true);
